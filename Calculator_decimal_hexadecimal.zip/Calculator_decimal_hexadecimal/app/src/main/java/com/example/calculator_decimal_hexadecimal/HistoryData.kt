package com.example.calculator_decimal_hexadecimal

import android.content.Context
import android.text.SpannableString
import android.text.style.ForegroundColorSpan

object HistoryData {
    val HistoryList = mutableListOf<SpannableString>()

    fun addOperation(nr1: String, op: String, nr2: String, res: String, bs: String, context: Context)
    {
        //selectam culoarea corecta in functie de baza in care suntem
        val color = if(bs == "select baza 10") {
            context.getColor(R.color.pastel_green)
        } else {
            context.getColor(R.color.pastel_pink)
        }

        //setam culoarea corecta
        val line0 = SpannableString("$bs").apply { setSpan(ForegroundColorSpan(color), 0, length, 0) }
        val line1 = SpannableString("$nr1 $op").apply { setSpan(ForegroundColorSpan(color), 0, length, 0) }
        val line2 = SpannableString("$nr2 =").apply { setSpan(ForegroundColorSpan(color), 0, length, 0) }
        val line3 = SpannableString("$res = $nr1 $op $nr2").apply { setSpan(ForegroundColorSpan(color), 0, length, 0) }

        //adaugam liniile colorate in lista
        HistoryList.add(line0)
        HistoryList.add(line1)
        HistoryList.add(line2)
        HistoryList.add(line3)
    }

    fun getAll(): List<SpannableString> {
        return HistoryList
    }
}