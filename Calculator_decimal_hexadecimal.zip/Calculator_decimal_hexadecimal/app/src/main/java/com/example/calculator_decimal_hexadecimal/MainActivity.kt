package com.example.calculator_decimal_hexadecimal

import android.content.Intent
import android.os.Bundle
import java.math.BigInteger
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    //declaram variabilele
    var maxLenght = 15 //limita maxima pentru numerele in baza 10, baza 10 initiala
    private lateinit var textAnterior: TextView
    private lateinit var textCurent: TextView
    private lateinit var button0: Button
    private lateinit var button1: Button
    private lateinit var button2: Button
    private lateinit var button3: Button
    private lateinit var button4: Button
    private lateinit var button5: Button
    private lateinit var button6: Button
    private lateinit var button7: Button
    private lateinit var button8: Button
    private lateinit var button9: Button
    private lateinit var buttonA: Button
    private lateinit var buttonB: Button
    private lateinit var buttonC: Button
    private lateinit var buttonD: Button
    private lateinit var buttonE: Button
    private lateinit var buttonF: Button
    private lateinit var button10_16: Button
    private lateinit var buttonBack: Button
    private lateinit var buttonPlus: Button
    private lateinit var buttonMinus: Button
    private lateinit var buttonStar: Button
    private lateinit var buttonEqual: Button
    private lateinit var historyLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        //de aici putem scrie in onCreate:))

        //initializam variabilele
        textAnterior = findViewById(R.id.textAnterior)
        textCurent = findViewById(R.id.textCurent)
        button0 = findViewById(R.id.button0)
        button1 = findViewById(R.id.button1)
        button2 = findViewById(R.id.button2)
        button3 = findViewById(R.id.button3)
        button4 = findViewById(R.id.button4)
        button5 = findViewById(R.id.button5)
        button6 = findViewById(R.id.button6)
        button7 = findViewById(R.id.button7)
        button8 = findViewById(R.id.button8)
        button9 = findViewById(R.id.button9)
        buttonA = findViewById(R.id.buttonA)
        buttonB = findViewById(R.id.buttonB)
        buttonC = findViewById(R.id.buttonC)
        buttonD = findViewById(R.id.buttonD)
        buttonE = findViewById(R.id.buttonE)
        buttonF = findViewById(R.id.buttonF)
        button10_16 = findViewById(R.id.button10_16)
        buttonBack = findViewById(R.id.buttonBack)
        buttonPlus = findViewById(R.id.buttonPlus)
        buttonMinus = findViewById(R.id.buttonMinus)
        buttonStar = findViewById(R.id.buttonStar)
        buttonEqual = findViewById(R.id.buttonEqual)
        historyLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val number = result.data?.getStringExtra("selected_number")
                if(number != null) {
                    textCurent.text = number
                }
            }
        }


        //verificam daca am primit numar din HistoryACtivity
        val selectedNumber = intent.getStringExtra("selected_number")
        if(selectedNumber != null)
            //setam numarul primit in textCurent
            textCurent.text = selectedNumber

        //setam OnClickListener pentru fiecare buton de la 0 la F si butoanele +, -, *
        button0.setOnClickListener { v: View? ->
            val currentText = textCurent.text.toString()
            if(textAnterior.text.last() != '-' && textAnterior.text.last() != '+' && textAnterior.text.last() != '*') //vreau ca atunci cand in textAnterior am un rezultat si apas pe o tasta care nu e operator, sa resetez calculatorul
                textAnterior.text = "0"
            // daca textul este doar 0 il lasam 0, altfel adaugam la textul deja scris valoarea 0
            if (currentText == "0") {
                textCurent.text = "0"
            } else {
                if(textCurent.text.length < maxLenght)
                    appendToTextView("0")
            }
        }
        button1.setOnClickListener { v: View? ->
            val currentText = textCurent.text.toString()
            if(textAnterior.text.last() != '-' && textAnterior.text.last() != '+' && textAnterior.text.last() != '*') //vreau ca atunci cand in textAnterior am un rezultat si apas pe o tasta care nu e operator, sa resetez calculatorul
                textAnterior.text = "0"
            // daca textul este doar 0 il inlocuim cu 1, altfel adaugam 1 la textul deja scris
            if (currentText == "0") {
                textCurent.text = "1"
            } else {
                if(textCurent.text.length < maxLenght)
                    appendToTextView("1")
            }
        }
        button2.setOnClickListener { v: View? ->
            val currentText = textCurent.text.toString()
            if(textAnterior.text.last() != '-' && textAnterior.text.last() != '+' && textAnterior.text.last() != '*') //vreau ca atunci cand in textAnterior am un rezultat si apas pe o tasta care nu e operator, sa resetez calculatorul
                textAnterior.text = "0"
            if (currentText == "0") {
                textCurent.text = "2"
            } else {
                if(textCurent.text.length < maxLenght)
                    appendToTextView("2")
            }
        }
        button3.setOnClickListener { v: View? ->
            val currentText = textCurent.text.toString()
            if(textAnterior.text.last() != '-' && textAnterior.text.last() != '+' && textAnterior.text.last() != '*') //vreau ca atunci cand in textAnterior am un rezultat si apas pe o tasta care nu e operator, sa resetez calculatorul
                textAnterior.text = "0"
            if (currentText == "0") {
                textCurent.text = "3"
            } else {
                if(textCurent.text.length < maxLenght)
                    appendToTextView("3")
            }
        }
        button4.setOnClickListener { v: View? ->
            val currentText = textCurent.text.toString()
            if(textAnterior.text.last() != '-' && textAnterior.text.last() != '+' && textAnterior.text.last() != '*') //vreau ca atunci cand in textAnterior am un rezultat si apas pe o tasta care nu e operator, sa resetez calculatorul
                textAnterior.text = "0"
            if (currentText == "0") {
                textCurent.text = "4"
            } else {
                if(textCurent.text.length < maxLenght)
                    appendToTextView("4")
            }
        }
        button5.setOnClickListener { v: View? ->
            val currentText = textCurent.text.toString()
            if(textAnterior.text.last() != '-' && textAnterior.text.last() != '+' && textAnterior.text.last() != '*') //vreau ca atunci cand in textAnterior am un rezultat si apas pe o tasta care nu e operator, sa resetez calculatorul
                textAnterior.text = "0"
            if (currentText == "0") {
                textCurent.text = "5"
            } else {
                if(textCurent.text.length < maxLenght)
                    appendToTextView("5")
            }
        }
        button6.setOnClickListener { v: View? ->
            val currentText = textCurent.text.toString()
            if(textAnterior.text.last() != '-' && textAnterior.text.last() != '+' && textAnterior.text.last() != '*') //vreau ca atunci cand in textAnterior am un rezultat si apas pe o tasta care nu e operator, sa resetez calculatorul
                textAnterior.text = "0"
            if (currentText == "0") {
                textCurent.text = "6"
            } else {
                if(textCurent.text.length < maxLenght)
                    appendToTextView("6")
            }
        }
        button7.setOnClickListener { v: View? ->
            val currentText = textCurent.text.toString()
            if(textAnterior.text.last() != '-' && textAnterior.text.last() != '+' && textAnterior.text.last() != '*') //vreau ca atunci cand in textAnterior am un rezultat si apas pe o tasta care nu e operator, sa resetez calculatorul
                textAnterior.text = "0"
            if (currentText == "0") {
                textCurent.text = "7"
            } else {
                if(textCurent.text.length < maxLenght)
                    appendToTextView("7")
            }
        }
        button8.setOnClickListener { v: View? ->
            val currentText = textCurent.text.toString()
            if(textAnterior.text.last() != '-' && textAnterior.text.last() != '+' && textAnterior.text.last() != '*') //vreau ca atunci cand in textAnterior am un rezultat si apas pe o tasta care nu e operator, sa resetez calculatorul
                textAnterior.text = "0"
            if (currentText == "0") {
                textCurent.text = "8"
            } else {
                if(textCurent.text.length < maxLenght)
                    appendToTextView("8")
            }
        }
        button9.setOnClickListener { v: View? ->
            val currentText = textCurent.text.toString()
            if(textAnterior.text.last() != '-' && textAnterior.text.last() != '+' && textAnterior.text.last() != '*') //vreau ca atunci cand in textAnterior am un rezultat si apas pe o tasta care nu e operator, sa resetez calculatorul
                textAnterior.text = "0"
            if (currentText == "0") {
                textCurent.text = "9"
            } else {
                if(textCurent.text.length < maxLenght)
                    appendToTextView("9")
            }
        }

        buttonA.setOnClickListener { v: View? ->
            val currentText = textCurent.text.toString()
            if(textAnterior.text.last() != '-' && textAnterior.text.last() != '+' && textAnterior.text.last() != '*') //vreau ca atunci cand in textAnterior am un rezultat si apas pe o tasta care nu e operator, sa resetez calculatorul
                textAnterior.text = "0"
            if (currentText == "0") {
                textCurent.text = "A"
            } else {
                if(textCurent.text.length < maxLenght)
                    appendToTextView("A")
            }
        }
        buttonB.setOnClickListener { v: View? ->
            val currentText = textCurent.text.toString()
            if(textAnterior.text.last() != '-' && textAnterior.text.last() != '+' && textAnterior.text.last() != '*') //vreau ca atunci cand in textAnterior am un rezultat si apas pe o tasta care nu e operator, sa resetez calculatorul
                textAnterior.text = "0"
            if (currentText == "0") {
                textCurent.text = "B"
            } else {
                if(textCurent.text.length < maxLenght)
                    appendToTextView("B")
            }
        }
        buttonC.setOnClickListener { v: View? ->
            val currentText = textCurent.text.toString()
            if(textAnterior.text.last() != '-' && textAnterior.text.last() != '+' && textAnterior.text.last() != '*') //vreau ca atunci cand in textAnterior am un rezultat si apas pe o tasta care nu e operator, sa resetez calculatorul
                textAnterior.text = "0"
            if (currentText == "0") {
                textCurent.text = "C"
            } else {
                if(textCurent.text.length < maxLenght)
                    appendToTextView("C")
            }
        }
        buttonD.setOnClickListener { v: View? ->
            val currentText = textCurent.text.toString()
            if(textAnterior.text.last() != '-' && textAnterior.text.last() != '+' && textAnterior.text.last() != '*') //vreau ca atunci cand in textAnterior am un rezultat si apas pe o tasta care nu e operator, sa resetez calculatorul
                textAnterior.text = "0"
            if (currentText == "0") {
                textCurent.text = "D"
            } else {
                if(textCurent.text.length < maxLenght)
                    appendToTextView("D")
            }
        }
        buttonE.setOnClickListener { v: View? ->
            val currentText = textCurent.text.toString()
            if(textAnterior.text.last() != '-' && textAnterior.text.last() != '+' && textAnterior.text.last() != '*') //vreau ca atunci cand in textAnterior am un rezultat si apas pe o tasta care nu e operator, sa resetez calculatorul
                textAnterior.text = "0"
            if (currentText == "0") {
                textCurent.text = "E"
            } else {
                if(textCurent.text.length < maxLenght)
                    appendToTextView("E")
            }
        }
        buttonF.setOnClickListener { v: View? ->
            val currentText = textCurent.text.toString()
            if(textAnterior.text.last() != '-' && textAnterior.text.last() != '+' && textAnterior.text.last() != '*') //vreau ca atunci cand in textAnterior am un rezultat si apas pe o tasta care nu e operator, sa resetez calculatorul
                textAnterior.text = "0"
            if (currentText == "0") {
                textCurent.text = "F"
            } else {
                if(textCurent.text.length < maxLenght)
                    appendToTextView("F")
            }
        }

        //dezactivam butoanele de la A la F pentru ca initial aplicatia este in baza 10
        buttonA.isEnabled = false
        buttonB.isEnabled = false
        buttonC.isEnabled = false
        buttonD.isEnabled = false
        buttonE.isEnabled = false
        buttonF.isEnabled = false

        //setam butoanele cu gri atunci cand suntem in baza 10 pentru ca initial suntem in baza 10
        buttonA.backgroundTintList = resources.getColorStateList(R.color.gray, theme)
        buttonB.backgroundTintList = resources.getColorStateList(R.color.gray, theme)
        buttonC.backgroundTintList = resources.getColorStateList(R.color.gray, theme)
        buttonD.backgroundTintList = resources.getColorStateList(R.color.gray, theme)
        buttonE.backgroundTintList = resources.getColorStateList(R.color.gray, theme)
        buttonF.backgroundTintList = resources.getColorStateList(R.color.gray, theme)

        //dezactivam butonul =
        buttonEqual.isEnabled = false

        buttonPlus.setOnClickListener { v: View? ->
            val anteriorText = textAnterior.text.toString()
            val currentText = textCurent.text.toString()

            if(anteriorText.first() == '=') {
                //daca avem egal (adica daca avem un rezulat si dorim sa continuam sa calculam cu el, adaugam operatorul
                textAnterior.text = (anteriorText.substring(2, anteriorText.length))
                textAnterior.append("+")
            }
            else if(anteriorText.last() == '-' || anteriorText.last() == '+' || anteriorText.last() == '*') {
                //daca dorim sa schibam operatorul putem face asta aici
                //ori daca apasam din nou din greseala pe acelasi operator, acesta ramane neschimbat
                textAnterior.text = (anteriorText.substring(0, anteriorText.length - 1))
                textAnterior.append("+")
            }
            else if(currentText.isNotEmpty()) {
                textAnterior.text = "$currentText+"
                textCurent.text = "0"
            }
            //activam butonul =
            buttonEqual.isEnabled = true
        }
        buttonMinus.setOnClickListener { v: View? ->
            val anteriorText = textAnterior.text.toString()
            val currentText = textCurent.text.toString()

            if(anteriorText.first() == '=') {
                //daca avem egal (adica daca avem un rezulat si dorim sa continuam sa calculam cu el, adaugam operatorul
                textAnterior.text = (anteriorText.substring(2, anteriorText.length))
                textAnterior.append("-")
            }
            else if(anteriorText.last() == '-' || anteriorText.last() == '+' || anteriorText.last() == '*') {
                //daca dorim sa schibam operatorul putem face asta aici
                //ori daca apasam din nou din greseala pe acelasi operator, acesta ramane neschimbat
                textAnterior.text = (anteriorText.substring(0, anteriorText.length - 1))
                textAnterior.append("-")
            }
            else if(currentText.isNotEmpty()) {
                textAnterior.text = "$currentText-"
                textCurent.text = "0"
            }
            //activam butonul =
            buttonEqual.isEnabled = true
        }
        buttonStar.setOnClickListener { v: View? ->
            val anteriorText = textAnterior.text.toString()
            val currentText = textCurent.text.toString()

            if(anteriorText.first() == '=') {
                //daca avem egal (adica daca avem un rezulat si dorim sa continuam sa calculam cu el, adaugam operatorul
                textAnterior.text = (anteriorText.substring(2, anteriorText.length))
                textAnterior.append("*")
            }
            else if(anteriorText.last() == '-' || anteriorText.last() == '+' || anteriorText.last() == '*') {
                //daca dorim sa schibam operatorul putem face asta aici
                //ori daca apasam din nou din greseala pe acelasi operator, acesta ramane neschimbat
                textAnterior.text = (anteriorText.substring(0, anteriorText.length - 1))
                textAnterior.append("*")
            }
            else if(currentText.isNotEmpty()) {
                textAnterior.text = "$currentText*"
                textCurent.text = "0"
            }

            //activam butonul =
            buttonEqual.isEnabled = true
        }

        button10_16.setOnClickListener {
            isHexMode = !isHexMode

            //activam sau dezactivam butoanele de la A la F
            buttonA.isEnabled = isHexMode
            buttonB.isEnabled = isHexMode
            buttonC.isEnabled = isHexMode
            buttonD.isEnabled = isHexMode
            buttonE.isEnabled = isHexMode
            buttonF.isEnabled = isHexMode

            //schimbam culoarea butonului si textului + convertim numerele + schimbam limita textului pe care il putem adauga in textCurent
            if(isHexMode) {

                //limita in baza 16
                maxLenght = 12

                //setam butoanele cu verde atunci cand suntem in baza 16
                buttonA.backgroundTintList = resources.getColorStateList(R.color.green, theme)
                buttonB.backgroundTintList = resources.getColorStateList(R.color.green, theme)
                buttonC.backgroundTintList = resources.getColorStateList(R.color.green, theme)
                buttonD.backgroundTintList = resources.getColorStateList(R.color.green, theme)
                buttonE.backgroundTintList = resources.getColorStateList(R.color.green, theme)
                buttonF.backgroundTintList = resources.getColorStateList(R.color.green, theme)

                button10_16.backgroundTintList = resources.getColorStateList(R.color.pastel_pink, theme)
                textAnterior.setTextColor(resources.getColor(R.color.pastel_pink))
                textCurent.setTextColor(resources.getColor(R.color.pastel_pink))

                //convertim textul din decimal in hexadecimal
                val currentText = textCurent.text.toString()
                val anteriorText = textAnterior.text.toString()

                //vedem daca in textAnterior avem un rezultat, adica daca avem semnul =, pentru ca atunci cand convertim sa il adaugam
                var e_egal = ""
                if(textAnterior.text.first() == '=')
                    e_egal = "="


                //convertim textul curent si textul anterior in noua baza
                val newTextCurent = convertToBase(currentText, 10, 16)
                val newTextAnterior = convertToBase(anteriorText, 10, 16)

                //Actualizam textul
                textCurent.text = newTextCurent
                if(e_egal == "=") {
                    textAnterior.text = "= $newTextAnterior"
                }
                else {
                    textAnterior.text = newTextAnterior
                }
            }
            else {

                //limita in baza 10
                maxLenght = 15

                //setam butoanele cu gri atunci cand suntem in baza 10
                buttonA.backgroundTintList = resources.getColorStateList(R.color.gray, theme)
                buttonB.backgroundTintList = resources.getColorStateList(R.color.gray, theme)
                buttonC.backgroundTintList = resources.getColorStateList(R.color.gray, theme)
                buttonD.backgroundTintList = resources.getColorStateList(R.color.gray, theme)
                buttonE.backgroundTintList = resources.getColorStateList(R.color.gray, theme)
                buttonF.backgroundTintList = resources.getColorStateList(R.color.gray, theme)

                button10_16.backgroundTintList = resources.getColorStateList(R.color.pastel_green, theme)
                textAnterior.setTextColor(resources.getColor(R.color.pastel_green))
                textCurent.setTextColor(resources.getColor(R.color.pastel_green))

                //convertim textul din hexadecimal in decimal
                val currentText = textCurent.text.toString()
                val anteriorText = textAnterior.text.toString()

                //convertim textul curent si textul anterior in noua baza
                val newTextCurent = convertToBase(currentText, 16, 10)
                val newTextAnterior = convertToBase(anteriorText, 16, 10)

                //vedem daca in textAnterior avem un rezultat, adica daca avem semnul =, pentru ca atunci cand convertim sa il adaugam
                var e_egal = ""
                if(textAnterior.text.first() == '=')
                    e_egal = "="

                //Actualizam textul
                textCurent.text = newTextCurent
                if(e_egal == "=") {
                    textAnterior.text = "= $newTextAnterior"
                }
                else {
                    textAnterior.text = newTextAnterior
                }

            }
        }

        this.buttonBack.setOnClickListener {
            val currentText = textCurent.text.toString()
            if(currentText.isNotEmpty())
            {
                textCurent.text = currentText.substring(0, currentText.length - 1)
                // creeam un subtring din stringul principal minus ultimul caracter
                if(textCurent.text.toString().isEmpty())
                    textCurent.text = "0"
            }
            else
                textCurent.text = "0"
        }

        buttonEqual.setOnClickListener {
            val operator = textAnterior.text.toString().last()
            val number1 = textAnterior.text.toString().substring(0, textAnterior.text.toString().length - 1)
            val number2 = textCurent.text.toString()

            val base = if(isHexMode) 16 else 10 //daca suntem in baza 16 base va fi 16 altfel 10

            val num1 = BigInteger(number1, base) //convertim number1 care era un string la baza de care avem nevoie
            val num2 = BigInteger(number2, base)

            val result: BigInteger = when (operator) {
                '+' -> num1 + num2
                '-' -> num1 - num2
                '*' -> num1 * num2
                else -> BigInteger.ZERO
            }

            //rezultatul va fi convertit inapoi in baza actuala
            val resultText = if(isHexMode) Integer.toHexString(result.toInt()).uppercase() else result.toString()

            textAnterior.text = "= $resultText"
            textCurent.text = "0"
            buttonEqual.isEnabled = false

            //vedem baza in care suntem pentru a stii ce afisam
            val baseText = if(isHexMode) "select baza 16" else "select baza 10"

            //adaugam in istoric operatia si numerele
            HistoryData.addOperation(number1, operator.toString(), number2, resultText, baseText, this)
        }

        supportActionBar?.setDisplayShowTitleEnabled(false) //pentru a nu mai aparea titlul aplicatiei in actionbar
    }

    //Incarcam meniul
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    //Gestionam actiunile din meniu
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId){
            R.id.action_history -> {
                //Cand apasam pe "Istoric", deschidem HistoryActivity
                val intent = Intent(this, HistoryActivity::class.java)
                historyLauncher.launch(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    //functie pentru a adauga la textview atunci cand unul dintre butoanele 1-9, A-F este apasat
    private fun appendToTextView(text: String)
    {
        textCurent.append(text)
    }

    //functie pentru convertirea unui numar din baza 10 in baza 16 sau invers
    fun convertToBase(value: String, fromBase: Int, toBase: Int): String {
        try {
            //verificam daca valoarea contine un semn de calcul si il eliminam temporar (asta pentru momentul in care exista text in TextAnterior
            var operator = when {
                value.contains('+') -> "+" //acel semn -> inseamna ca operator ia valoarea, asa functioneaza structura when
                value.contains('-') -> "-"
                value.contains("*") -> "*"
                else -> ""
            }

            //extragem doar partile "numerice" inclusiv literele A-F, nu extragem operatorii
            val number = value.filter { it.isDigit() || it in 'A'..'F'}

            //convertim valoareaa de la baza initiala la un intreg
            val intValue = BigInteger(number, fromBase)

            //convertim
            return if (toBase == 10) {
                intValue.toString() + operator //daca vrem sa convertim in baza 10 si adaugam operatorul daca acesta exista
            } else {
                Integer.toHexString(intValue.toInt()).toUpperCase() + operator //pentru a converti in baza 16 si adaugam operatorul daca acesta exista
            }
        } catch (e: Exception) {
            return value //in caz de eroare returnam valorea originala
        }
    }

    //cream functiile pentru a salvat si restitui instantele atunci cand rotim telefonul
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("savedText1", textAnterior.text.toString()) //salvam textul anterior
        outState.putString("savedText2", textCurent.text.toString()) //salvam textul curent
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        val savedText2 = savedInstanceState.getString("savedText2", "")
        val savedText1 = savedInstanceState.getString("savedText1", "")

        textAnterior.text = savedText1
        textCurent.text = savedText2
    }

    //setam variabila intr un obiect ca sa o pot vedea de oriunde
    companion object {
        var isHexMode: Boolean = false
    }
}