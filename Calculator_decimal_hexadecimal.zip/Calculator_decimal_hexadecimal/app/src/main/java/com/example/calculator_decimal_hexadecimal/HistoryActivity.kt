package com.example.calculator_decimal_hexadecimal

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.math.BigInteger

class HistoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        //aici putem scrie in onCreate

        val History = findViewById<ListView>(R.id.History)
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, HistoryData.getAll())
        History.adapter = adapter

        //pentru a seta bara de scroll astfel incat sa vad mereu ultimul element
        History.setSelection(adapter.count - 1)

        //adaugam un onClickListener pentru a detecta apasarea unei linii
        History.setOnItemClickListener { _, _, position, _ ->
            //luam linia selectata din istoric
            val selectedLine = HistoryData.getAll()[position]

            //extragem primul numar din linie
            val number = extractFirstNumber(selectedLine.toString())

            //memoram baza in care se afla numarul, in cazul in care am selectat o linie pe care avem un numar
            var numberBase = 10 //initial presupunem ca baza este 10
            if(number != "") {
                for (i in 1..3) {
                    //daca nu ni s-au terminat liniile (e aproape imposbil sa nu gasim baza inante de a se termina liniile dar ok:)) )
                    if(position - i >= 0) {
                        val line = HistoryData.getAll()[position - i]
                        if(line.contains("baza 16"))
                            numberBase = 16
                    }
                }
                //convertim numarul la BigInteger din baza sursa
                val bigNumber = BigInteger(number, numberBase)

                //convertim numarul
                val calculatorBase = if(MainActivity.isHexMode) 16 else 10
                val converted = if(calculatorBase == 16) bigNumber.toString(16).uppercase() else bigNumber.toString()

                //trimitem numarul convertit catre MainActivity
                val intent = Intent()
                intent.putExtra("selected_number", converted)
                setResult(RESULT_OK, intent)
                finish()
            }
        }
    }

    //Incarcam meniul
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_history, menu)
        return true
    }

    //Gestionam actiunile din meniu
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            //Acest id corespunde cu butonul "calcul"
            R.id.action_calcul -> {
                //Inchidem HistoryActivity si deschidem activitatea principala (MainActivity)
                finish()
                true
            }
            R.id.action_email -> {
                //Se trimite emailul cu istoricul la apasarea butonului email
                sendEmail()
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    private fun sendEmail() {

        //obtinem continutul istoricului, dupa care punem fiecare element pe o linie separata pentru a putea sa l trimitem pe mail
        val HistoryList = HistoryData.getAll()
        val emaiBody = HistoryList.joinToString("\n") { it.toString() }

        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "message/rfc822" //spune androidului ca vom trimite un mesaj de tip email rfc822 = Standard Format for ARPA Internet Text Messages
        intent.putExtra(Intent.EXTRA_EMAIL, arrayOf("emanuelcosereanu7@gmail.com"))
        intent.putExtra(Intent.EXTRA_SUBJECT, "Istoric calculator decimal si hexadecimal") //titlul emailului
        intent.putExtra(Intent.EXTRA_TEXT, emaiBody) //corpul emailului

        //daca putem trimite emailul o face, daca nu,afisam ca am intampinat erori (nu s-au gasit aplicatii sa trimitem mailul)
        try {
            startActivity(Intent.createChooser(intent, "Trimteti emailul..."))
        } catch (e: android.content.ActivityNotFoundException) {
            Toast.makeText(this, "Nu exista aplicatii pentru trimiterea emailului", Toast.LENGTH_SHORT).show()
        }
    }

    //functie pentru a extrage numarul de pe linie(primul numar) si a putea sa il trimitem catre
    private fun extractFirstNumber(line: String): String {
        //verificam daca linia incepe cu un numar sau un caracter valid (A-F), altfel am apasat pe linia cu "selec baza x"
        if(line.isNotEmpty() && (line.first().isDigit() || line.first().toUpperCase() in 'A'..'F')) {
            //luam doar primul numar de pe linie (in caz ca cineva vrea sa ia si numarul care e rezultat
            var number = ""
            for(char in line) {
                if(char.isDigit() || char.toUpperCase() in 'A'..'F')
                    number += char;
                else
                    break
            }
            return number
        }
        return "" //returneaza un sir gol daca nu este un numar valid (adica daca apasam pe o linie de selectare a bazei)
    }

}